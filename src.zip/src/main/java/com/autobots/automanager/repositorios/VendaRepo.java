package com.autobots.automanager.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VendaRepo  extends JpaRepository<VendaRepo, Long> {
    
}
