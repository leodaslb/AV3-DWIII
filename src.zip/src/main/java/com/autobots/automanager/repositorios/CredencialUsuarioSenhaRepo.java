package com.autobots.automanager.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.autobots.automanager.entidades.CredencialUsuarioSenha;

public interface CredencialUsuarioSenhaRepo  extends JpaRepository<CredencialUsuarioSenha, Long> {
    
}
