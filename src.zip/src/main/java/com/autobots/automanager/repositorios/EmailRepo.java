package com.autobots.automanager.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.autobots.automanager.entidades.Email;

public interface EmailRepo  extends JpaRepository<Email, Long> {
    
}
