package com.autobots.automanager.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CredencialCodigoBarra  extends JpaRepository<CredencialCodigoBarra, Long> {
    
}
